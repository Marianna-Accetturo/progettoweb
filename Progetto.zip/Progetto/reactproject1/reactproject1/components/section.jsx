/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-key */
import Card from './card'

export default function Section({title, cardContent}) {
    return (
        <section>
            <h2>{title}</h2>
            <div className="section">
                {cardContent.map(c => <Card url={c.url} descrizione={c.descrizione}/>)}
            </div>
        </section>
    )
}