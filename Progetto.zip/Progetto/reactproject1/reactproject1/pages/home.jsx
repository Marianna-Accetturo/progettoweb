/* eslint-disable react/jsx-key */
import useState from 'react'
import useEffect from 'react'
import contentData from '../content.json'
import Section from '../components/section'

export default function Home() {
    const [content, setContent] = useState(null)
    useEffect(() => {setContent(contentData)},[])
    return (
        <home id="home">
            {content.data.map(c => <Section title={c.title}
                cardContent={c.cardContent}/>)}
        </home>
    )
}