require('dotenv').config();
const express = require ('express');
const app = express();
const cors = require('cors');
const corsOptions = require('./config/corsOptions');
const { logger } = require('./middleware/logEvents');
const errorHandler = require('./middleware/errorHandler');
const cookieParser = require('cookie-parser');
const corsAccessControl = require('./middleware/corsAccessControl');
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const router = require('./router/index');

connectDB(); 

app.use(logger);
app.use(corsAccessControl); 
app.use(cors(corsOptions)); 
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser()); 


app.use(router);
app.all('*', (req, res) => res.sendStatus(404));
app.use(errorHandler);

mongoose.connection.once('open', () => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
});