//non so se questa parte è stata già fatta
const Origins = [
    'http://127.0.0.1:3000',
    'http://localhost:3000'
];

module.exports = Origins;

