const ROLES_LIST = {
    'Admin': 'Admin',
    'User1': 'User1',
    'User2': 'User2',
    'User3': 'User3'
}

module.exports = ROLES_LIST;