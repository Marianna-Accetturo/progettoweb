require('dotenv').config();
const User = require('./models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const handleLogin = async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ 'message': 'Username and password are required.' });

    const foundUser = await User.findOne({ email: username }).exec();
    if (!foundUser) return res.sendStatus(401); 

    const passwordMatch = await bcrypt.compare(password, foundUser.password);
    if (passwordMatch) {
        const roles = foundUser.type;
        
        const apiJWToken = jwt.sign(
            {
                "User": {
                    "username": foundUser.email,
                    "roles": roles
                }
            },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: '30s' }
        );
        const cookieJWToken = jwt.sign(
            { "username": foundUser.email },
            process.env.COOKIE_TOKEN_SECRET,
            { expiresIn: '1d' }
        );
        
        foundUser.cookieJWToken = cookieJWToken;
        foundUser.save().then(result => {
            console.log(result);
            const fullName = `${result?.firstName} ${result?.lastName}`;

            res.cookie('jwt', cookieJWToken, { httpOnly: true, secure: process.env.SECURE_COOKIE === "true" ? true : false, sameSite: 'None', maxAge: 24 * 60 * 60 * 1000 });

            res.json({ fullName, roles, apiJWToken });
        });
    } else {
        res.sendStatus(401);
    }

}

module.exports = { handleLogin };