const User = require('./models/User');
const bcrypt = require('bcrypt');

const handleNewUser = async (req, res) => {
    const firstName = req.body.firstName;
    const lastName = req.body.lastName;
    const email = req.body.email;
    const password = req.body.password;
    const type = req.body.type;

    if (!firstName || !lastName || !email || !password || !type) return res.status(400).json({ 'message': 'Error in receiving data' });

    const duplicate = await User.findOne({ email: email }).exec();
    if (duplicate) return res.sendStatus(409); 

    try {
        const saltRounds = 10;
        const hashedPsw = await bcrypt.hash(password, saltRounds); 
        const result = await User.create({
            "firstName": firstName,
            "lastName": lastName,
            "type": type,
            "email": email,
            "password": hashedPsw
        }); 
        console.log(`USER CREATED: ${result}`);
        res.status(201).json({ success: `USER CREATED: ${result}` });
    } catch (err) {
        console.log(`ERROR CREATING USER: ${err.message}`);
        res.status(500).json({ 'message': `ERROR CREATING USER: ${err.message}` });
    }
}

module.exports = { handleNewUser };