const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
  firstName: String,
  lastName: String,
  type: {
    type: String,
    enum: {
      values: ['Admin', 'User1', 'User2', 'User3']
    }
  },
  email: {
    type: String,
    unique: true,
    required: true
  },
  password: {
    type: String,
    required: true
  },
});

module.exports = mongoose.model("User", userSchema);