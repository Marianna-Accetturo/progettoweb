const User = require('./models/User');
const jwt = require('jsonwebtoken');

const handleRefresh = async (req, res) => {
    const cookies = req.cookies;
    if (!cookies?.jwt) return res.status(401).json("Cookie jwt not found");
    const cookieJWToken = cookies.jwt;

    const foundUser = await User.findOne({ cookieJWToken }).exec();
    if (!foundUser) return res.sendStatus(403); 

    const fullName = `${foundUser.firstName} ${foundUser.lastName}`;
    const username = foundUser.email;

    jwt.verify(
        cookieJWToken,
        process.env.COOKIE_TOKEN_SECRET,
        (err, decoded) => {
            if (err || foundUser.email !== decoded.username) return res.sendStatus(403);
            const roles = foundUser.type;
            const apiJWToken = jwt.sign(
                {
                    "User": {
                        "username": decoded.username,
                        "roles": roles
                    }
                },
                process.env.ACCESS_TOKEN_SECRET,
                { expiresIn: '10s' }
            );
            res.json({ fullName, username, roles, apiJWToken })
        }
    );
}

module.exports = { handleRefresh }