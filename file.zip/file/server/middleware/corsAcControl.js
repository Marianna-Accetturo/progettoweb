const Origins = require('../config/Origins');

const corsAcControl = (req, res, next) => {
    const origin = req.headers.origin;
    if (Origins.includes(origin)) {
        res.header('Access-Control-Allow-Credentials', true);
    }
    next();
}

module.exports = corsAcControl;