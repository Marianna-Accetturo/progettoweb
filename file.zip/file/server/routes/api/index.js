const express = require('express');
const verifyJWT = require('../middleware/verifyJWT');
const router = express.Router();

router.use('/setup', require('./setupR'));
router.use('/register', require('./registerR'));
router.use('/getToken', require('./routes'));
router.use('/refresh', require('./refreshR'));
router.use('/logout', require('./logoutR'));

router.use(verifyJWT);
router.use('/api/v1/users', require('./api/users'));

module.exports = router;