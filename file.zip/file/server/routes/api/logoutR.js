const express = require('express');
const router = express.Router();
const logoutR = require('../controllers/logout');

router.get('/', logoutR.handleLogout);

module.exports = router;