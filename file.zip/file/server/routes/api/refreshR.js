const express = require('express');
const router = express.Router();
const refreshR = require('../controllers/refresh');

router.get('/', refreshR.handleRefresh);

module.exports = router;