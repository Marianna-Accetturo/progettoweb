const express = require('express');
const bcrypt = require('bcrypt');
const User = require("../models/User");

const router = express.Router();

router.get('/', async (req, res) => {
    const exists = await User.exists({ email: "admin@gmail.com" });
    if (exists) return res.status(409).json({ error: "Admin User Already Created" });
    try {
        const saltRounds = 10;
        const hashedPsw = await bcrypt.hash("1234", saltRounds);
        const result = await User.create({
            "firstName": "Gruppo",
            "lastName": "Web",
            "type": "Admin",
            "email": "admin@gmail.com",
            "password": hashedPsw
        });
        console.log(`USER CREATED: ${result}`);
        res.status(201).json({ success: `USER CREATED: ${result}` });
    } catch (err) {
        console.log(`ERROR CREATING USER: ${err.message}`);
        res.status(500).json({ 'message': `ERROR CREATING USER: ${err.message}` });
    }
});

module.exports = router;