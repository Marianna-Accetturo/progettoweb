export default function VideoRow({title, type, date, items}) {
    return (
      <tr><td>
        <div class="Video-item">
        <img class="album" />
        <div class="description">
            <h1>{title}</h1>
            <p>{type}</p>
        </div>
      </div>
      </td>
        <td>{items.reduce((p, i) => p + i.length, 0)}</td>
        <td>{items.length}</td>
        <td>{date}</td>
      </tr>
    )
  }