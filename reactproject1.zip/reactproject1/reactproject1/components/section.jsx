import PropTypes from 'prop-types'
import Card from './card'

export default function Section({ title, cardContent}) {
    return (
        <section>
            <h2>{title}</h2>
            <p>{cardContent.url}</p>
            <div className="section">
                {cardContent?.map((c, index) => <Card key={index} title={c.title} cardContent={c.cardContent} />)}
            </div>
        </section>
    )
}

Section.propTypes = {
    title: PropTypes.node,
    cardContent : PropTypes.node
}