export default function PersonalArea(prop) {
    return (
        <>
            <h2>Hello {prop.name}!</h2>  
        </>
    )
}